# HTML-CSS-JavaScript
It is a project that I learnt from Udemy course : The Web Developer Bootcamp by Colt Steele

![image] - Home Page
(https://user-images.githubusercontent.com/43831111/47926107-227edc00-de96-11e8-8344-d0057af0dfc9.png)
